import React from "react";
import "./App.css";
import Contacts from "./app/screen/contacts";

interface AppProps {
  name?: string;
}

function App<AppProps>() {
  return <Contacts />;
}

export default App;
