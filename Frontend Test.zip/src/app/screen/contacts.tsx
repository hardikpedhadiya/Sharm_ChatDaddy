import React, { useState, useEffect } from "react";
import {
  MenuTwoTone,
  CheckCircle,
  Delete,
  AddCircle,
  Search,
} from "@material-ui/icons";
import { Button } from "@material-ui/core";
import axios from "axios";

import ContactCard from "../components/ContactCard";
import "./contacts.css";

export interface ContactProps {
  id: string;
  accountId: string;
  type: string;
  name: string;
  phoneNumber: string;
  platformNames: [];
  messagesSent: number;
  messagesReceived: number;
  createdAt: string;
  img: object;
  assignee: object;
  tags: [];
  checked?: boolean;
}

interface tags {
  name: string;
  checked?: boolean;
}

function Contacts() {
  const [search, setSearch] = useState<string>("");
  const [storeTags, setStoreTags] = useState<tags[]>([]);
  const [includeTags, setIncludeTags] = useState<tags[]>([]);
  const [excludeTags, setExcludeTags] = useState<tags[]>([]);
  const [filteredList, setFilteredList] = useState<any>([]);
  const [contactList, setContactList] = useState<any>([]);
  const [selectAll, setSelectAll] = useState<boolean>(false);
  const [applyFilter, setApplyFilter] = useState<boolean>(false);
  const [messageSentMin, setMessageSentMin] = useState<string>();
  const [messageSentMax, setMessageSentMax] = useState<string>();
  const [messageReceivedMin, setMessageReceivedMin] = useState<string>();
  const [messageReceivedMax, setMessageReceivedMax] = useState<string>();

  const toggleApplyFilters = () => setApplyFilter(!applyFilter);
  const keyArray = (objArray: tags[], key: string) =>
    objArray.map(function (item) {
      return item["name"];
    });

  useEffect(() => {
    let tempIncludeTags: string[] = [];
    let tempExcludeTags: string[] = [];
    let tempContacts = [...contactList];
    let tempFilteredList: any[] = [];
    if (applyFilter) {
      setSearch("");
      includeTags.map((item: any) => {
        if (item.checked) tempIncludeTags.push(item.name);
      });
      excludeTags.map((item: any) => {
        if (item.checked) tempExcludeTags.push(item.name);
      });
      if (
        tempIncludeTags.length > 0 ||
        tempExcludeTags.length > 0 ||
        messageSentMin != "" ||
        messageSentMax != "" ||
        messageReceivedMin != "" ||
        messageReceivedMax != ""
      ) {
        tempFilteredList = tempContacts;
        if (tempIncludeTags.length > 0)
          tempFilteredList = tempContacts.filter((item) =>
            keyArray(item.tags, "name").some((r) =>
              tempIncludeTags.includes(r!)
            )
          );

        if (tempExcludeTags.length > 0)
          tempFilteredList = tempFilteredList.filter((item) =>
            keyArray(item.tags, "name").some(
              (r) => !tempExcludeTags.includes(r!)
            )
          );

        if (messageSentMin != "")
          tempFilteredList = tempFilteredList.filter(
            (item) => item.messagesSent >= Number(messageSentMin || 0)
          );

        if (messageSentMax != "")
          tempFilteredList = tempFilteredList.filter(
            (item) => item.messagesSent <= Number(messageSentMax || 0)
          );

        if (messageReceivedMin != "")
          tempFilteredList = tempFilteredList.filter(
            (item) => item.messagesReceived >= Number(messageReceivedMin || 0)
          );

        if (messageReceivedMax != "")
          tempFilteredList = tempFilteredList.filter(
            (item) => item.messagesReceived <= Number(messageReceivedMax || 0)
          );

        setFilteredList(tempFilteredList);
      } else {
        toggleApplyFilters();
      }
    } else {
      setApplyFilter(false);
      setIncludeTags(storeTags);
      setExcludeTags(storeTags);
      setMessageSentMin("");
      setMessageSentMax("");
      setMessageReceivedMin("");
      setMessageReceivedMax("");
    }
  }, [applyFilter]);

  useEffect(() => {
    if (search.length > 0) {
      let tempContacts = [...contactList];
      const tempFilteredData = tempContacts.filter((item: any) =>
        item.name.toLowerCase().includes(search.toLowerCase())
      );
      setFilteredList(tempFilteredData);
    } else {
      // setFilteredList([]);
    }
  }, [search]);

  const updateSelection = (data: any) => {
    let tempContacts: any = [...contactList];
    const index = tempContacts.findIndex((x: any) => x.id === data.id);
    const tempData = { ...tempContacts[index] }.checked;
    const updatedData = {
      ...tempContacts[index],
      checked: tempData ? false : true,
    };
    tempContacts[index] = updatedData;
    setContactList(tempContacts);
  };

  const updateFilteredSelection = (data: any) => {
    let tempContacts: any = [...filteredList];
    const index = tempContacts.findIndex((x: any) => x.id === data.id);
    const tempData = { ...tempContacts[index] }.checked;
    const updatedData = {
      ...tempContacts[index],
      checked: tempData ? false : true,
    };
    tempContacts[index] = updatedData;
    setFilteredList(tempContacts);
    updateSelection(data);
  };

  const filterIncludeTags = (index: number) => {
    let tempIncludeTags: any = [...includeTags];
    const tempData = { ...tempIncludeTags[index] }.checked;
    const updatedData = {
      ...tempIncludeTags[index],
      checked: tempData ? false : true,
    };
    tempIncludeTags[index] = updatedData;
    setIncludeTags(tempIncludeTags);
  };

  const filterExcludeTags = (index: number) => {
    let tempExcludeTags: any = [...excludeTags];
    const tempData = { ...tempExcludeTags[index] }.checked;
    const updatedData = {
      ...tempExcludeTags[index],
      checked: tempData ? false : true,
    };
    tempExcludeTags[index] = updatedData;
    setExcludeTags(tempExcludeTags);
  };

  useEffect(() => {
    getToken();
  }, []);

  useEffect(() => {
    if (search.length == 0 && !applyFilter) {
      let tempContacts: any = [...contactList];
      let data = tempContacts.map((item: any) => {
        return { ...item, checked: selectAll };
      });
      setContactList(data);
    } else {
      let tempContacts: any = [...filteredList];

      let data = tempContacts.map((item: any) => {
        return { ...item, checked: selectAll };
      });
      setFilteredList(data);
    }
  }, [selectAll]);

  const getToken = async () => {
    const headers = {
      "Content-Type": "application/json",
    };
    const data = {
      refreshToken: "059c420e-7424-431f-b23b-af0ecabfe7b8",
      teamId: "a001994b-918b-4939-8518-3377732e4e88",
    };
    axios
      .post("https://api-teams.chatdaddy.tech/token", data, {
        headers: headers,
      })
      .then((res) => {
        const config = {
          headers: {
            "Content-Type": "application/json",
            Authorization: "Bearer " + res.data.access_token,
          },
        };
        axios
          .get("https://api-im.chatdaddy.tech/tags", config)
          .then((res) => {
            setStoreTags(res.data.tags);
            setIncludeTags(res.data.tags);
            setExcludeTags(res.data.tags);
          })
          .catch((error) => {
            console.log(error);
          });
        axios
          .get("https://api-im.chatdaddy.tech/contacts", config)
          .then((res) => {
            setContactList(res.data.contacts);
          })
          .catch((error) => {
            console.log(error);
          });
      })
      .catch((error) => {
        console.log(error);
      });
  };
  return (
    <div className="contact-container container-fluid">
      <div className="side-menu">
        <div>
          <div className="side-menu-header">
            <div>
              <MenuTwoTone />
              <span className="audience">Audience</span>
            </div>
            <span className="contacts-count">
              {contactList.length} contacts
            </span>
          </div>
          <div className="side-menu-container">
            <div className="include-tags mt-1">
              <span className="include-tags-title">Include Tags:</span>
              <div className="mt-2">
                {includeTags.map((item, index) => (
                  <div className="side-menu-list">
                    <span className="side-menu-list-txt">{item.name}</span>
                    <div>
                      <Delete
                        className="side-menu-list-actionBtn"
                        fontSize="small"
                        htmlColor="#e43033"
                      />
                      <button onClick={() => filterIncludeTags(index)}>
                        <CheckCircle
                          className="side-menu-list-actionBtn"
                          fontSize="small"
                          htmlColor={
                            item.checked ? "#09a391" : " rgb(178, 190, 209)"
                          }
                        />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="include-tags mt-3">
              <span className="include-tags-title">Exclude Tags:</span>
              <div className="mt-2">
                {excludeTags.map((item, index) => (
                  <div className="side-menu-list">
                    <span className="side-menu-list-txt">{item.name}</span>
                    <div>
                      <Delete
                        className="side-menu-list-actionBtn"
                        fontSize="small"
                        htmlColor="#e43033"
                      />
                      <button onClick={() => filterExcludeTags(index)}>
                        <CheckCircle
                          className="side-menu-list-actionBtn"
                          fontSize="small"
                          htmlColor={
                            item.checked ? "#09a391" : " rgb(178, 190, 209)"
                          }
                        />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="include-tags mt-3">
              <span className="include-tags-title">Message Sent:</span>
              <div className="mt-2">
                <div className="min-max">
                  <input
                    type={"number"}
                    placeholder="Min"
                    value={messageSentMin}
                    onChange={(e) => setMessageSentMin(e.target.value)}
                  />
                  <input
                    type={"number"}
                    placeholder="Max"
                    value={messageSentMax}
                    onChange={(e) => setMessageSentMax(e.target.value)}
                  />
                </div>
              </div>
            </div>
            <div className="include-tags mt-3">
              <span className="include-tags-title">Message Received:</span>
              <div className="mt-2">
                <div className="min-max">
                  <input
                    type={"number"}
                    placeholder="Min"
                    value={messageReceivedMin}
                    onChange={(e) => setMessageReceivedMin(e.target.value)}
                  />
                  <input
                    type={"number"}
                    placeholder="Max"
                    value={messageReceivedMax}
                    onChange={(e) => setMessageReceivedMax(e.target.value)}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="save-filters">
          <Button
            onClick={toggleApplyFilters}
            style={{
              width: "100%",
              borderRadius: 5,
              backgroundColor: "#21b6ae",
              padding: "6px",
              fontSize: "12px",
              color: "white",
              textTransform: "none",
              zIndex: 0,
            }}
          >
            {applyFilter ? "Remove Filters" : "Save Filters"}
          </Button>
        </div>
      </div>
      <div className="working-area">
        <div className="working-header">
          <div className="working-menu-header">
            <span className="audience">All Contacts({contactList.length})</span>
            <Button>
              <AddCircle fontSize="medium" htmlColor="#09a391" />
            </Button>
          </div>
          <div className="search-container mt-2">
            <Search fontSize="small" htmlColor="rgb(167, 166, 166)" />
            <input
              className="search"
              placeholder="Search Contacts"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
        </div>
        <div className="working-list-main">
          {search.length == 0 && !applyFilter && (
            <div className="contact-list mt-2">
              <div className="contact-detail-left">
                <button onClick={() => setSelectAll(!selectAll)}>
                  <CheckCircle
                    htmlColor={selectAll ? "#09a391" : " rgb(178, 190, 209)"}
                  />
                </button>
                <span className="select-all">Select All</span>
              </div>
              <Button>
                <AddCircle fontSize="small" htmlColor="#09a391" />
              </Button>
            </div>
          )}
          {search.length == 0 && !applyFilter
            ? [...contactList].map((contact: any, index: number) => (
                <div className="mt-3">
                  <ContactCard
                    data={contact}
                    index={index}
                    updateSelection={updateSelection}
                    updateFilteredSelection={updateFilteredSelection}
                    update={search.length == 0 && !applyFilter}
                  />
                </div>
              ))
            : filteredList.map((contact: any, index: number) => (
                <ContactCard
                  data={contact}
                  index={index}
                  updateSelection={updateSelection}
                  updateFilteredSelection={updateFilteredSelection}
                  update={search.length == 0 && !applyFilter}
                />
              ))}
        </div>
      </div>
    </div>
  );
}

export default Contacts;
