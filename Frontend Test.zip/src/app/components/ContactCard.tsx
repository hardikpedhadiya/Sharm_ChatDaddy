import React from "react";
import { CheckCircle, AddCircle } from "@material-ui/icons";
import { Button } from "@material-ui/core";

import { ContactProps } from "../screen/contacts";
export interface ContactCardProps {
  data: ContactProps;
  index?: number;
  updateSelection: (data: any) => void;
  updateFilteredSelection: (data: any) => void;
  update: boolean;
}

const ContactCard = ({
  data,
  updateSelection,
  updateFilteredSelection,
  update,
}: ContactCardProps) => {
  return (
    <div className="contact-list mt-2">
      <div className="contact-detail-left">
        <button
          onClick={() =>
            update ? updateSelection(data) : updateFilteredSelection(data)
          }
        >
          <CheckCircle
            htmlColor={data.checked ? "#09a391" : " rgb(178, 190, 209)"}
          />
        </button>
        <img height={40} width={40} className="contact-profile" />
        <div className="details">
          <span className="name">{data.name}</span>
          <span className="mobileNumber">{data.phoneNumber}</span>
        </div>
      </div>
      <Button>
        <AddCircle fontSize="small" htmlColor="#09a391" />
      </Button>
    </div>
  );
};

export default ContactCard;
